package westbahn;
public enum ZeitkartenTyp {

	WOCHENKARTE, MONATSKARTE, JAHRESKARTE
}
