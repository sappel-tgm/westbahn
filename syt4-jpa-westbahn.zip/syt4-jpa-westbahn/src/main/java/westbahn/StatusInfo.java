package westbahn;
public enum StatusInfo {
	DELAYED, CANCELLED, ONTIME
}
