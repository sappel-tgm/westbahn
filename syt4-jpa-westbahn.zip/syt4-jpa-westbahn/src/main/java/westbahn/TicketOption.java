package westbahn;
public enum TicketOption {
	FAHRRAD, GROSSGEPAECK
}
