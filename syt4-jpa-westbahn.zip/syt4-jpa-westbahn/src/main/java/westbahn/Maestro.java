package westbahn;
public class Maestro implements Zahlung {


	/**
	 * @see Zahlung#zahlungDurchfuehren()
	 * 
	 *  
	 */
	public void zahlungDurchfuehren() {

	}

}
