package westbahn;
public class Praemienmeilen implements Zahlung {


	/**
	 * @see Zahlung#zahlungDurchfuehren()
	 * 
	 *  
	 */
	public void zahlungDurchfuehren() {

	}

}
