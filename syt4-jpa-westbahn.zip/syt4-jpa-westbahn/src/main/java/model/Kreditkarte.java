package model;
public class Kreditkarte implements Zahlung {


	/**
	 * @see Zahlung#zahlungDurchfuehren()
	 * 
	 *  
	 */
	public void zahlungDurchfuehren() {

	}

}
