package model;
public enum TicketOption {
	FAHRRAD, GROSSGEPAECK
}
