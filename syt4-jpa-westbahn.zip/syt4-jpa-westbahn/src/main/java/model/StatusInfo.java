package model;
public enum StatusInfo {
	DELAYED, CANCELLED, ONTIME
}
