package model;
public enum ZeitkartenTyp {

	WOCHENKARTE, MONATSKARTE, JAHRESKARTE
}
